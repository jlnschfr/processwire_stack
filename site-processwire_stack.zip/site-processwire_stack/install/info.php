<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "", 
	'summary' => "", 
	'screenshot' => ""
	);
