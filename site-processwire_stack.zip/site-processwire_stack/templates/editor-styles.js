/* globals CKEDITOR */

CKEDITOR.stylesSet.add("mystyles", [
  { name: "Large Text", element: "p", attributes: { class: "Text--large" } },
  { name: "Medium Text", element: "p", attributes: { class: "Text--medium" } },
  { name: "Small Text", element: "p", attributes: { class: "Text--small" } }
]);
